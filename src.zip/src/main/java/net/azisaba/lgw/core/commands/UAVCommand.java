package net.azisaba.lgw.core.commands;

import net.azisaba.lgw.core.LeonGunWar;
import net.azisaba.lgw.core.MatchManager;
import net.azisaba.lgw.core.util.BattleTeam;
import net.azisaba.lgw.core.util.Chat;
import net.azisaba.lgw.core.util.LgwLog;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UAVCommand implements CommandExecutor {
    private final Logger logger = LgwLog.getLogger(this.getClass());

    private final double uavRadius = 60d;
    private final double uavSeconds = 2d;

    private final Map<Player, Long> lastExecuted = new HashMap<>();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        // コンソールではない場合はreturn
        if (sender instanceof Player) {
            sender.sendMessage(Chat.f("&cこのコマンドはConsoleでのみ実行可能です。"));
            return true;
        }

        // UAVを使用したプレイヤーが指定されていない場合はreturn
        if (args.length == 0) {
            sender.sendMessage(Chat.f("&cUsage: {0}", cmd.getUsage().replace("{LABEL}", label)));
            return true;
        }

        // 使用したプレイヤーを取得
        Player shooter = Bukkit.getPlayerExact(args[0]);

        // プレイヤーが存在しない場合はメッセージを表示してreturn
        if (shooter == null) {
            sender.sendMessage(Chat.f("&cプレイヤーが見つかりません。"));
            return true;
        }

        // 前に実行した時間から1秒経っていない場合はreturn
        if (lastExecuted.getOrDefault(shooter, 0L) + 1000 > System.currentTimeMillis()) {
            return true;
        }

        // 実行した時間を指定
        lastExecuted.put(shooter, System.currentTimeMillis());

        // 試合のプレイヤーリスト取得
        MatchManager manager = LeonGunWar.getPlugin().getManager();
        List<Player> allPlayers = manager.getAllTeamPlayers();
        Map<BattleTeam, List<Player>> teamPlayerMap = manager.getTeamPlayers();

        // プレイヤーがチームに所属していない場合はメッセージを表示
        if (!allPlayers.contains(shooter)) {
            logger.warn("{} はどのチームにも所属していません。", shooter.getName());
            shooter.sendMessage(Chat.f("&cあなたはどのチームにも所属していません。"));
            return true;
        }

        // 各チームのプレイヤーを取得し、発行を付与する
        for (BattleTeam team : teamPlayerMap.keySet()) {
            // プレイヤーリスト取得
            List<Player> players = teamPlayerMap.get(team);

            // 使用したプレイヤーが含まれている場合return
            if (players.contains(shooter)) {
                continue;
            }

            // 各プレイヤーに発行を付与する
            players.forEach(target -> {
                // ワールドが違う場合はreturn
                if (target.getLocation().getWorld() != shooter.getLocation().getWorld()) {
                    return;
                }

                // 距離がConfigで指定された距離よりも遠い場合はreturn
                if (target.getLocation().distance(shooter.getLocation()) > uavRadius) {
                    return;
                }

                // tickと強さを取得/設定
                int l = (int) (uavSeconds * 20);
                int amp = 1;

                // ログを出力
                logger.info("{}にGLOWINGを付与 (time={}ticks, level={})", target.getName(), l, amp);

                // 発行を付与
                target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, l, amp, false, false));
            });
        }

        // 完了ログを出力
        logger.info("正常に {} のUAVを実行しました。", shooter.getName());
        return true;
    }
}
