package net.azisaba.lgw.core.events;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * プレイヤーがエントリー解除したときに呼び出されるイベント
 *
 * @author siloneco
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PlayerLeaveEntryMatchEvent extends Event {

    private static final HandlerList HANDLERS_LIST = new HandlerList();
    // エントリー解除したプレイヤー
    private final Player leavePlayer;

    public PlayerLeaveEntryMatchEvent(Player player) {
        this.leavePlayer = player;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS_LIST;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS_LIST;
    }
}
