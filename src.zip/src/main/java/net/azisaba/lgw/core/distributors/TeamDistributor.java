package net.azisaba.lgw.core.distributors;

import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import java.util.List;

/**
 * プレイヤーをチームに振り分けるクラスのためのインターフェース
 *
 * @author siloneco
 */
public interface TeamDistributor {

    /**
     * プレイヤーをチームに均等に振り分けます 基本は同じ人数になるように振り分けしますが、今後KDによって振り分けるときのためにインターフェースで実装します
     *
     * @param plist 振り分けたいプレイヤーのリスト
     * @param teams チームのリスト
     */
    void distributePlayers(List<Player> plist, List<Team> teams);

    /**
     * 指定されたプレイヤーをどちらかのチームに振り分けます
     *
     * @param p     振り分けたいプレイヤー
     * @param teams チームのリスト
     */
    void distributePlayer(Player p, List<Team> teams);

    /**
     * スコアボードなどに表示する、振り分け方式の名前を指定します
     *
     * @return 振り分け方式の名前
     */
    String getDistributorName();
}
